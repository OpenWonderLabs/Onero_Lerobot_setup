"""MoveIt2 launch for A1_dual arms.

Brings up the standard MoveIt2 action interfaces (/move_group, /execute_trajectory)
on top of the existing arm_control_node. Default mode is safe dryrun:
  - dryrun=true            -> bridge logs but does not publish joint_position_command
  - start_arm_control=false-> arm_control_node not started (assume already running)
  - fake_joint_states=true -> joint_state_publisher publishes zero positions
                              (use when arm_control_node is not actually running)
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

import xacro
import yaml


def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _read_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def launch_setup(context, *args, **kwargs):
    pkg_share = FindPackageShare("armcontrol").perform(context)

    xacro_path = f"{pkg_share}/urdf/A1_dual/A1_dual.urdf.xacro"
    srdf_path = f"{pkg_share}/config/moveit/A1_dual.srdf"
    kinematics_path = f"{pkg_share}/config/moveit/kinematics.yaml"
    joint_limits_path = f"{pkg_share}/config/moveit/joint_limits.yaml"
    moveit_controllers_path = f"{pkg_share}/config/moveit/moveit_controllers.yaml"
    ompl_path = f"{pkg_share}/config/moveit/ompl_planning.yaml"

    robot_description = {
        "robot_description": xacro.process_file(xacro_path).toxml()
    }
    robot_description_semantic = {
        "robot_description_semantic": _read_text(srdf_path)
    }
    robot_description_kinematics = {
        "robot_description_kinematics": _read_yaml(kinematics_path)
    }
    robot_description_planning = {
        "robot_description_planning": _read_yaml(joint_limits_path)
    }
    moveit_controllers = _read_yaml(moveit_controllers_path)

    ompl_yaml = _read_yaml(ompl_path)
    ompl_planning_pipeline = {
        "planning_pipelines": ["ompl"],
        "default_planning_pipeline": "ompl",
        "ompl": ompl_yaml,
    }

    trajectory_execution = {
        "moveit_manage_controllers": True,
        "trajectory_execution.allowed_execution_duration_scaling": 1.2,
        "trajectory_execution.allowed_goal_duration_margin": 0.5,
        "trajectory_execution.allowed_start_tolerance": 0.05,
    }

    planning_scene_monitor_parameters = {
        "publish_planning_scene": True,
        "publish_geometry_updates": True,
        "publish_state_updates": True,
        "publish_transforms_updates": True,
    }

    dryrun = LaunchConfiguration("dryrun")
    start_arm_control = LaunchConfiguration("start_arm_control")
    fake_joint_states = LaunchConfiguration("fake_joint_states")

    nodes = []

    nodes.append(Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[robot_description, {"publish_frequency": 50.0}],
    ))

    # Fake joint_state_publisher for dryrun mode (when arm_control_node is
    # not running and there's no real /joint_states source).
    nodes.append(Node(
        package="joint_state_publisher",
        executable="joint_state_publisher",
        name="joint_state_publisher",
        output="screen",
        parameters=[robot_description, {"rate": 30}],
        condition=IfCondition(fake_joint_states),
    ))

    # Optional: spin up arm_control_node (normally already running via grasp.launch.py).
    nodes.append(Node(
        package="armcontrol",
        executable="arm_control_node",
        name="arm_control_node",
        output="screen",
        condition=IfCondition(start_arm_control),
    ))

    nodes.append(Node(
        package="moveit_ros_move_group",
        executable="move_group",
        name="move_group",
        output="screen",
        parameters=[
            robot_description,
            robot_description_semantic,
            robot_description_kinematics,
            robot_description_planning,
            moveit_controllers,
            ompl_planning_pipeline,
            trajectory_execution,
            planning_scene_monitor_parameters,
            {"use_sim_time": False},
        ],
    ))

    nodes.append(Node(
        package="armcontrol",
        executable="arm_moveit_bridge",
        name="arm_moveit_bridge",
        output="screen",
        parameters=[
            {"dryrun": dryrun},
            {"publish_rate": 100.0},
            {"start_tolerance": 0.05},
            {"goal_tolerance": 0.10},
            {"goal_time_margin": 0.3},
        ],
    ))

    return nodes


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            "dryrun", default_value="true",
            description="Safety switch: when true, bridge logs but does not publish "
                        "joint_position_command. Must be explicitly set to false to "
                        "drive the real arms."),
        DeclareLaunchArgument(
            "start_arm_control", default_value="false",
            description="Start arm_control_node from this launch. Default false; "
                        "the real-machine deployment normally starts it via grasp.launch.py."),
        DeclareLaunchArgument(
            "fake_joint_states", default_value="true",
            description="Start joint_state_publisher to emit zero joint states. "
                        "Set false on the real machine where arm_control_node publishes "
                        "/joint_states."),
        OpaqueFunction(function=launch_setup),
    ])
