#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rviz 显示整机 robot.urdf(armcontrol/urdf/<model_version>/robot.urdf)。
直接加载 x1(不再嫁接 grasp/robot.urdf),与 MuJoCo 用的是同一个模型。

用法:
  ros2 launch armcontrol robot_model_rviz.launch.py                 # 手动滑块调关节
  ros2 launch armcontrol robot_model_rviz.launch.py use_gui:=false  # 跟随外部 /joint_states(如 MuJoCo plant)
  ros2 launch armcontrol robot_model_rviz.launch.py model_version:=v3.3
该版本无 robot.urdf 时直接报错、启动失败。
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _nodes(context, *args, **kwargs):
    version = LaunchConfiguration("model_version").perform(context)
    use_gui = LaunchConfiguration("use_gui").perform(context).lower() in ("1", "true", "yes")
    share = get_package_share_directory("armcontrol")

    urdf_path = os.path.join(share, "urdf", version, "robot.urdf")
    if not os.path.isfile(urdf_path):
        raise RuntimeError(
            f"[robot_model_rviz] 找不到 {urdf_path};该版本({version})无 robot.urdf,启动失败。")
    with open(urdf_path, "r", encoding="utf-8") as f:
        robot_description = f.read()

    rviz_config = os.path.join(share, "rviz", "robot_model_rviz.rviz")

    nodes = [
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="robot_state_publisher",
            output="screen",
            parameters=[{"robot_description": robot_description}],
        ),
        Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            output="screen",
            arguments=(["-d", rviz_config] if os.path.isfile(rviz_config) else []),
        ),
    ]
    if use_gui:
        # 手动滑块调关节;若要跟随 MuJoCo/真机的 /joint_states,设 use_gui:=false
        nodes.insert(1, Node(
            package="joint_state_publisher_gui",
            executable="joint_state_publisher_gui",
            name="joint_state_publisher_gui",
            output="screen",
        ))
    return nodes


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("model_version", default_value="v3.1",
                              description="加载 armcontrol/urdf/<version>/robot.urdf"),
        DeclareLaunchArgument("use_gui", default_value="true",
                              description="true: 滑块手动调; false: 跟随外部 /joint_states"),
        OpaqueFunction(function=_nodes),
    ])
