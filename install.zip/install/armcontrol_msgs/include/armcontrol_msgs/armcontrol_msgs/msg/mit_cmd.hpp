// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARMCONTROL_MSGS__MSG__MIT_CMD_HPP_
#define ARMCONTROL_MSGS__MSG__MIT_CMD_HPP_

#include "armcontrol_msgs/msg/detail/mit_cmd__struct.hpp"
#include "armcontrol_msgs/msg/detail/mit_cmd__builder.hpp"
#include "armcontrol_msgs/msg/detail/mit_cmd__traits.hpp"
#include "armcontrol_msgs/msg/detail/mit_cmd__type_support.hpp"

#endif  // ARMCONTROL_MSGS__MSG__MIT_CMD_HPP_
