// generated from rosidl_generator_c/resource/idl.h.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

#ifndef ARMCONTROL_MSGS__MSG__MIT_CMD_H_
#define ARMCONTROL_MSGS__MSG__MIT_CMD_H_

#include "armcontrol_msgs/msg/detail/mit_cmd__struct.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__functions.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__type_support.h"

#endif  // ARMCONTROL_MSGS__MSG__MIT_CMD_H_
