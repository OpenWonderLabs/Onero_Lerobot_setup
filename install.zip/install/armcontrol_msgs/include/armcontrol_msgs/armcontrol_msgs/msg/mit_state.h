// generated from rosidl_generator_c/resource/idl.h.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

#ifndef ARMCONTROL_MSGS__MSG__MIT_STATE_H_
#define ARMCONTROL_MSGS__MSG__MIT_STATE_H_

#include "armcontrol_msgs/msg/detail/mit_state__struct.h"
#include "armcontrol_msgs/msg/detail/mit_state__functions.h"
#include "armcontrol_msgs/msg/detail/mit_state__type_support.h"

#endif  // ARMCONTROL_MSGS__MSG__MIT_STATE_H_
