// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_cmd.hpp"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TRAITS_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "armcontrol_msgs/msg/detail/mit_cmd__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace armcontrol_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const MitCmd & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: name
  {
    if (msg.name.size() == 0) {
      out << "name: []";
    } else {
      out << "name: [";
      size_t pending_items = msg.name.size();
      for (auto item : msg.name) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: kp
  {
    if (msg.kp.size() == 0) {
      out << "kp: []";
    } else {
      out << "kp: [";
      size_t pending_items = msg.kp.size();
      for (auto item : msg.kp) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: kd
  {
    if (msg.kd.size() == 0) {
      out << "kd: []";
    } else {
      out << "kd: [";
      size_t pending_items = msg.kd.size();
      for (auto item : msg.kd) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: q_des
  {
    if (msg.q_des.size() == 0) {
      out << "q_des: []";
    } else {
      out << "q_des: [";
      size_t pending_items = msg.q_des.size();
      for (auto item : msg.q_des) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: dq_des
  {
    if (msg.dq_des.size() == 0) {
      out << "dq_des: []";
    } else {
      out << "dq_des: [";
      size_t pending_items = msg.dq_des.size();
      for (auto item : msg.dq_des) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: tau_ff
  {
    if (msg.tau_ff.size() == 0) {
      out << "tau_ff: []";
    } else {
      out << "tau_ff: [";
      size_t pending_items = msg.tau_ff.size();
      for (auto item : msg.tau_ff) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MitCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.name.size() == 0) {
      out << "name: []\n";
    } else {
      out << "name:\n";
      for (auto item : msg.name) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.kp.size() == 0) {
      out << "kp: []\n";
    } else {
      out << "kp:\n";
      for (auto item : msg.kp) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.kd.size() == 0) {
      out << "kd: []\n";
    } else {
      out << "kd:\n";
      for (auto item : msg.kd) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: q_des
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q_des.size() == 0) {
      out << "q_des: []\n";
    } else {
      out << "q_des:\n";
      for (auto item : msg.q_des) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: dq_des
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.dq_des.size() == 0) {
      out << "dq_des: []\n";
    } else {
      out << "dq_des:\n";
      for (auto item : msg.dq_des) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: tau_ff
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.tau_ff.size() == 0) {
      out << "tau_ff: []\n";
    } else {
      out << "tau_ff:\n";
      for (auto item : msg.tau_ff) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MitCmd & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace armcontrol_msgs

namespace rosidl_generator_traits
{

[[deprecated("use armcontrol_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const armcontrol_msgs::msg::MitCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  armcontrol_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use armcontrol_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const armcontrol_msgs::msg::MitCmd & msg)
{
  return armcontrol_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<armcontrol_msgs::msg::MitCmd>()
{
  return "armcontrol_msgs::msg::MitCmd";
}

template<>
inline const char * name<armcontrol_msgs::msg::MitCmd>()
{
  return "armcontrol_msgs/msg/MitCmd";
}

template<>
struct has_fixed_size<armcontrol_msgs::msg::MitCmd>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<armcontrol_msgs::msg::MitCmd>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<armcontrol_msgs::msg::MitCmd>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TRAITS_HPP_
