// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_cmd.hpp"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__armcontrol_msgs__msg__MitCmd __attribute__((deprecated))
#else
# define DEPRECATED__armcontrol_msgs__msg__MitCmd __declspec(deprecated)
#endif

namespace armcontrol_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MitCmd_
{
  using Type = MitCmd_<ContainerAllocator>;

  explicit MitCmd_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit MitCmd_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _name_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _name_type name;
  using _kp_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _kp_type kp;
  using _kd_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _kd_type kd;
  using _q_des_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _q_des_type q_des;
  using _dq_des_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _dq_des_type dq_des;
  using _tau_ff_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _tau_ff_type tau_ff;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__name(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__kp(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->kp = _arg;
    return *this;
  }
  Type & set__kd(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->kd = _arg;
    return *this;
  }
  Type & set__q_des(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->q_des = _arg;
    return *this;
  }
  Type & set__dq_des(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->dq_des = _arg;
    return *this;
  }
  Type & set__tau_ff(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->tau_ff = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    armcontrol_msgs::msg::MitCmd_<ContainerAllocator> *;
  using ConstRawPtr =
    const armcontrol_msgs::msg::MitCmd_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      armcontrol_msgs::msg::MitCmd_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      armcontrol_msgs::msg::MitCmd_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__armcontrol_msgs__msg__MitCmd
    std::shared_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__armcontrol_msgs__msg__MitCmd
    std::shared_ptr<armcontrol_msgs::msg::MitCmd_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MitCmd_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->kp != other.kp) {
      return false;
    }
    if (this->kd != other.kd) {
      return false;
    }
    if (this->q_des != other.q_des) {
      return false;
    }
    if (this->dq_des != other.dq_des) {
      return false;
    }
    if (this->tau_ff != other.tau_ff) {
      return false;
    }
    return true;
  }
  bool operator!=(const MitCmd_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MitCmd_

// alias to use template instance with default allocator
using MitCmd =
  armcontrol_msgs::msg::MitCmd_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace armcontrol_msgs

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_HPP_
