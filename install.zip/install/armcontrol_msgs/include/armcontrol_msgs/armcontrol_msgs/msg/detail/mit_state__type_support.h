// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_state.h"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__TYPE_SUPPORT_H_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "armcontrol_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_armcontrol_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  armcontrol_msgs,
  msg,
  MitState
)(void);

#ifdef __cplusplus
}
#endif

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__TYPE_SUPPORT_H_
