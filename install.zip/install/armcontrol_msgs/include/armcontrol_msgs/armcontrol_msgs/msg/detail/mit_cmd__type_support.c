// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "rosidl_typesupport_interface/macros.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__struct.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__type_support.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif
