// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice
#include "armcontrol_msgs/msg/detail/mit_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `q`
// Member `dq`
// Member `tau`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
armcontrol_msgs__msg__MitState__init(armcontrol_msgs__msg__MitState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    armcontrol_msgs__msg__MitState__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__init(&msg->name, 0)) {
    armcontrol_msgs__msg__MitState__fini(msg);
    return false;
  }
  // q
  if (!rosidl_runtime_c__double__Sequence__init(&msg->q, 0)) {
    armcontrol_msgs__msg__MitState__fini(msg);
    return false;
  }
  // dq
  if (!rosidl_runtime_c__double__Sequence__init(&msg->dq, 0)) {
    armcontrol_msgs__msg__MitState__fini(msg);
    return false;
  }
  // tau
  if (!rosidl_runtime_c__double__Sequence__init(&msg->tau, 0)) {
    armcontrol_msgs__msg__MitState__fini(msg);
    return false;
  }
  return true;
}

void
armcontrol_msgs__msg__MitState__fini(armcontrol_msgs__msg__MitState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // name
  rosidl_runtime_c__String__Sequence__fini(&msg->name);
  // q
  rosidl_runtime_c__double__Sequence__fini(&msg->q);
  // dq
  rosidl_runtime_c__double__Sequence__fini(&msg->dq);
  // tau
  rosidl_runtime_c__double__Sequence__fini(&msg->tau);
}

bool
armcontrol_msgs__msg__MitState__are_equal(const armcontrol_msgs__msg__MitState * lhs, const armcontrol_msgs__msg__MitState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // q
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->q), &(rhs->q)))
  {
    return false;
  }
  // dq
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->dq), &(rhs->dq)))
  {
    return false;
  }
  // tau
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->tau), &(rhs->tau)))
  {
    return false;
  }
  return true;
}

bool
armcontrol_msgs__msg__MitState__copy(
  const armcontrol_msgs__msg__MitState * input,
  armcontrol_msgs__msg__MitState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // q
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->q), &(output->q)))
  {
    return false;
  }
  // dq
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->dq), &(output->dq)))
  {
    return false;
  }
  // tau
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->tau), &(output->tau)))
  {
    return false;
  }
  return true;
}

armcontrol_msgs__msg__MitState *
armcontrol_msgs__msg__MitState__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitState * msg = (armcontrol_msgs__msg__MitState *)allocator.allocate(sizeof(armcontrol_msgs__msg__MitState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(armcontrol_msgs__msg__MitState));
  bool success = armcontrol_msgs__msg__MitState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
armcontrol_msgs__msg__MitState__destroy(armcontrol_msgs__msg__MitState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    armcontrol_msgs__msg__MitState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
armcontrol_msgs__msg__MitState__Sequence__init(armcontrol_msgs__msg__MitState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitState * data = NULL;

  if (size) {
    data = (armcontrol_msgs__msg__MitState *)allocator.zero_allocate(size, sizeof(armcontrol_msgs__msg__MitState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = armcontrol_msgs__msg__MitState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        armcontrol_msgs__msg__MitState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
armcontrol_msgs__msg__MitState__Sequence__fini(armcontrol_msgs__msg__MitState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      armcontrol_msgs__msg__MitState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

armcontrol_msgs__msg__MitState__Sequence *
armcontrol_msgs__msg__MitState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitState__Sequence * array = (armcontrol_msgs__msg__MitState__Sequence *)allocator.allocate(sizeof(armcontrol_msgs__msg__MitState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = armcontrol_msgs__msg__MitState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
armcontrol_msgs__msg__MitState__Sequence__destroy(armcontrol_msgs__msg__MitState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    armcontrol_msgs__msg__MitState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
armcontrol_msgs__msg__MitState__Sequence__are_equal(const armcontrol_msgs__msg__MitState__Sequence * lhs, const armcontrol_msgs__msg__MitState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!armcontrol_msgs__msg__MitState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
armcontrol_msgs__msg__MitState__Sequence__copy(
  const armcontrol_msgs__msg__MitState__Sequence * input,
  armcontrol_msgs__msg__MitState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(armcontrol_msgs__msg__MitState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    armcontrol_msgs__msg__MitState * data =
      (armcontrol_msgs__msg__MitState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!armcontrol_msgs__msg__MitState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          armcontrol_msgs__msg__MitState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!armcontrol_msgs__msg__MitState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
