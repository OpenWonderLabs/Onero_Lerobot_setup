// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TYPE_SUPPORT_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "armcontrol_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_armcontrol_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  armcontrol_msgs,
  msg,
  MitCmd
)();
#ifdef __cplusplus
}
#endif

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__TYPE_SUPPORT_HPP_
