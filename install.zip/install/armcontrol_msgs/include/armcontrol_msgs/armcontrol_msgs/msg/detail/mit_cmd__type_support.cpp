// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__functions.h"
#include "armcontrol_msgs/msg/detail/mit_cmd__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace armcontrol_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void MitCmd_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) armcontrol_msgs::msg::MitCmd(_init);
}

void MitCmd_fini_function(void * message_memory)
{
  auto typed_message = static_cast<armcontrol_msgs::msg::MitCmd *>(message_memory);
  typed_message->~MitCmd();
}

size_t size_function__MitCmd__name(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__name(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__name(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__name(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const std::string *>(
    get_const_function__MitCmd__name(untyped_member, index));
  auto & value = *reinterpret_cast<std::string *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__name(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<std::string *>(
    get_function__MitCmd__name(untyped_member, index));
  const auto & value = *reinterpret_cast<const std::string *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__name(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

size_t size_function__MitCmd__kp(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__kp(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__kp(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__kp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__MitCmd__kp(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__kp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__MitCmd__kp(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__kp(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

size_t size_function__MitCmd__kd(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__kd(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__kd(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__kd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__MitCmd__kd(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__kd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__MitCmd__kd(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__kd(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

size_t size_function__MitCmd__q_des(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__q_des(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__q_des(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__q_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__MitCmd__q_des(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__q_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__MitCmd__q_des(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__q_des(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

size_t size_function__MitCmd__dq_des(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__dq_des(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__dq_des(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__dq_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__MitCmd__dq_des(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__dq_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__MitCmd__dq_des(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__dq_des(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

size_t size_function__MitCmd__tau_ff(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__MitCmd__tau_ff(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__MitCmd__tau_ff(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__MitCmd__tau_ff(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__MitCmd__tau_ff(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__MitCmd__tau_ff(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__MitCmd__tau_ff(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__MitCmd__tau_ff(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember MitCmd_message_member_array[7] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "name",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, name),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__name,  // size() function pointer
    get_const_function__MitCmd__name,  // get_const(index) function pointer
    get_function__MitCmd__name,  // get(index) function pointer
    fetch_function__MitCmd__name,  // fetch(index, &value) function pointer
    assign_function__MitCmd__name,  // assign(index, value) function pointer
    resize_function__MitCmd__name  // resize(index) function pointer
  },
  {
    "kp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, kp),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__kp,  // size() function pointer
    get_const_function__MitCmd__kp,  // get_const(index) function pointer
    get_function__MitCmd__kp,  // get(index) function pointer
    fetch_function__MitCmd__kp,  // fetch(index, &value) function pointer
    assign_function__MitCmd__kp,  // assign(index, value) function pointer
    resize_function__MitCmd__kp  // resize(index) function pointer
  },
  {
    "kd",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, kd),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__kd,  // size() function pointer
    get_const_function__MitCmd__kd,  // get_const(index) function pointer
    get_function__MitCmd__kd,  // get(index) function pointer
    fetch_function__MitCmd__kd,  // fetch(index, &value) function pointer
    assign_function__MitCmd__kd,  // assign(index, value) function pointer
    resize_function__MitCmd__kd  // resize(index) function pointer
  },
  {
    "q_des",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, q_des),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__q_des,  // size() function pointer
    get_const_function__MitCmd__q_des,  // get_const(index) function pointer
    get_function__MitCmd__q_des,  // get(index) function pointer
    fetch_function__MitCmd__q_des,  // fetch(index, &value) function pointer
    assign_function__MitCmd__q_des,  // assign(index, value) function pointer
    resize_function__MitCmd__q_des  // resize(index) function pointer
  },
  {
    "dq_des",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, dq_des),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__dq_des,  // size() function pointer
    get_const_function__MitCmd__dq_des,  // get_const(index) function pointer
    get_function__MitCmd__dq_des,  // get(index) function pointer
    fetch_function__MitCmd__dq_des,  // fetch(index, &value) function pointer
    assign_function__MitCmd__dq_des,  // assign(index, value) function pointer
    resize_function__MitCmd__dq_des  // resize(index) function pointer
  },
  {
    "tau_ff",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(armcontrol_msgs::msg::MitCmd, tau_ff),  // bytes offset in struct
    nullptr,  // default value
    size_function__MitCmd__tau_ff,  // size() function pointer
    get_const_function__MitCmd__tau_ff,  // get_const(index) function pointer
    get_function__MitCmd__tau_ff,  // get(index) function pointer
    fetch_function__MitCmd__tau_ff,  // fetch(index, &value) function pointer
    assign_function__MitCmd__tau_ff,  // assign(index, value) function pointer
    resize_function__MitCmd__tau_ff  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers MitCmd_message_members = {
  "armcontrol_msgs::msg",  // message namespace
  "MitCmd",  // message name
  7,  // number of fields
  sizeof(armcontrol_msgs::msg::MitCmd),
  false,  // has_any_key_member_
  MitCmd_message_member_array,  // message members
  MitCmd_init_function,  // function to initialize message memory (memory has to be allocated)
  MitCmd_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t MitCmd_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &MitCmd_message_members,
  get_message_typesupport_handle_function,
  &armcontrol_msgs__msg__MitCmd__get_type_hash,
  &armcontrol_msgs__msg__MitCmd__get_type_description,
  &armcontrol_msgs__msg__MitCmd__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace armcontrol_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<armcontrol_msgs::msg::MitCmd>()
{
  return &::armcontrol_msgs::msg::rosidl_typesupport_introspection_cpp::MitCmd_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, armcontrol_msgs, msg, MitCmd)() {
  return &::armcontrol_msgs::msg::rosidl_typesupport_introspection_cpp::MitCmd_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
