// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_state.hpp"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__armcontrol_msgs__msg__MitState __attribute__((deprecated))
#else
# define DEPRECATED__armcontrol_msgs__msg__MitState __declspec(deprecated)
#endif

namespace armcontrol_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MitState_
{
  using Type = MitState_<ContainerAllocator>;

  explicit MitState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit MitState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _name_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _name_type name;
  using _q_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _q_type q;
  using _dq_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _dq_type dq;
  using _tau_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _tau_type tau;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__name(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__q(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->q = _arg;
    return *this;
  }
  Type & set__dq(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->dq = _arg;
    return *this;
  }
  Type & set__tau(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->tau = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    armcontrol_msgs::msg::MitState_<ContainerAllocator> *;
  using ConstRawPtr =
    const armcontrol_msgs::msg::MitState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      armcontrol_msgs::msg::MitState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      armcontrol_msgs::msg::MitState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__armcontrol_msgs__msg__MitState
    std::shared_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__armcontrol_msgs__msg__MitState
    std::shared_ptr<armcontrol_msgs::msg::MitState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MitState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->q != other.q) {
      return false;
    }
    if (this->dq != other.dq) {
      return false;
    }
    if (this->tau != other.tau) {
      return false;
    }
    return true;
  }
  bool operator!=(const MitState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MitState_

// alias to use template instance with default allocator
using MitState =
  armcontrol_msgs::msg::MitState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace armcontrol_msgs

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_HPP_
