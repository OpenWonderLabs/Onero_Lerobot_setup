﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_state.h"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_H_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'q'
// Member 'dq'
// Member 'tau'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/MitState in the package armcontrol_msgs.
/**
  * MitState —— 仿真状态反馈(与 MitCmd 字段对称,便于 cmd/实际对比)
  * 由 MuJoCo plant 发到 /sim/<side>/state,arm_control_node_sim 读回当作电机读数。
  * 各数组长度 = 关节数 N(7),按关节顺序对应 name。
 */
typedef struct armcontrol_msgs__msg__MitState
{
  std_msgs__msg__Header header;
  /// 关节名,如 joint1-l .. joint7-l
  rosidl_runtime_c__String__Sequence name;
  /// 实际位置 rad
  rosidl_runtime_c__double__Sequence q;
  /// 实际速度 rad/s
  rosidl_runtime_c__double__Sequence dq;
  /// 实际施加力矩(qfrc_applied)N·m
  rosidl_runtime_c__double__Sequence tau;
} armcontrol_msgs__msg__MitState;

// Struct for a sequence of armcontrol_msgs__msg__MitState.
typedef struct armcontrol_msgs__msg__MitState__Sequence
{
  armcontrol_msgs__msg__MitState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} armcontrol_msgs__msg__MitState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__STRUCT_H_
