// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

#include "armcontrol_msgs/msg/detail/mit_cmd__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_armcontrol_msgs
const rosidl_type_hash_t *
armcontrol_msgs__msg__MitCmd__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x38, 0x5f, 0x3a, 0x02, 0x55, 0x62, 0xa0, 0xc1,
      0x16, 0x12, 0x40, 0x38, 0x82, 0x2e, 0x78, 0x34,
      0xc5, 0x6f, 0xec, 0xb3, 0xa3, 0xc0, 0x4e, 0xc6,
      0xda, 0xad, 0xfa, 0xc5, 0xf0, 0xf5, 0x47, 0x51,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char armcontrol_msgs__msg__MitCmd__TYPE_NAME[] = "armcontrol_msgs/msg/MitCmd";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__header[] = "header";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__name[] = "name";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__kp[] = "kp";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__kd[] = "kd";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__q_des[] = "q_des";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__dq_des[] = "dq_des";
static char armcontrol_msgs__msg__MitCmd__FIELD_NAME__tau_ff[] = "tau_ff";

static rosidl_runtime_c__type_description__Field armcontrol_msgs__msg__MitCmd__FIELDS[] = {
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__name, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__kp, 2, 2},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__kd, 2, 2},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__q_des, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__dq_des, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitCmd__FIELD_NAME__tau_ff, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription armcontrol_msgs__msg__MitCmd__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
armcontrol_msgs__msg__MitCmd__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {armcontrol_msgs__msg__MitCmd__TYPE_NAME, 26, 26},
      {armcontrol_msgs__msg__MitCmd__FIELDS, 7, 7},
    },
    {armcontrol_msgs__msg__MitCmd__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# MitCmd \\xe2\\x80\\x94\\xe2\\x80\\x94 \\xe4\\xbb\\xbf\\xe7\\x9c\\x9f MIT \\xe5\\x8a\\x9b\\xe4\\xbd\\x8d\\xe6\\xb7\\xb7\\xe5\\x90\\x88\\xe6\\x8e\\xa7\\xe5\\x88\\xb6\\xe6\\x8c\\x87\\xe4\\xbb\\xa4(\\xe6\\xaf\\x8f\\xe4\\xb8\\xaa\\xe5\\x85\\xb3\\xe8\\x8a\\x82 5 \\xe4\\xb8\\xaa\\xe9\\x87\\x8f)\n"
  "# \\xe7\\x94\\xb1 arm_control_node_sim \\xe5\\x8f\\x91\\xe5\\x88\\xb0 /sim/<side>/mit_cmd,MuJoCo plant \\xe5\\xa4\\x8d\\xe7\\x8e\\xb0:\n"
  "#   tau = kp*(q_des - q) + kd*(dq_des - dq) + tau_ff\n"
  "# \\xe5\\x90\\x84\\xe6\\x95\\xb0\\xe7\\xbb\\x84\\xe9\\x95\\xbf\\xe5\\xba\\xa6 = \\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe6\\x95\\xb0 N(7),\\xe6\\x8c\\x89\\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe9\\xa1\\xba\\xe5\\xba\\x8f\\xe5\\xaf\\xb9\\xe5\\xba\\x94 name[i]\\xe3\\x80\\x82\n"
  "std_msgs/Header header\n"
  "string[]  name      # \\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe5\\x90\\x8d,\\xe5\\xa6\\x82 joint1-l .. joint7-l\n"
  "float64[] kp        # \\xe6\\xaf\\x94\\xe4\\xbe\\x8b\\xe5\\xa2\\x9e\\xe7\\x9b\\x8a\n"
  "float64[] kd        # \\xe5\\xbe\\xae\\xe5\\x88\\x86\\xe5\\xa2\\x9e\\xe7\\x9b\\x8a\n"
  "float64[] q_des     # \\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe4\\xbd\\x8d\\xe7\\xbd\\xae rad\n"
  "float64[] dq_des    # \\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe9\\x80\\x9f\\xe5\\xba\\xa6 rad/s\n"
  "float64[] tau_ff    # \\xe5\\x89\\x8d\\xe9\\xa6\\x88\\xe5\\x8a\\x9b\\xe7\\x9f\\xa9(\\xe9\\x87\\x8d\\xe5\\x8a\\x9b/\\xe5\\x8a\\xa8\\xe5\\x8a\\x9b\\xe5\\xad\\xa6\\xe8\\xa1\\xa5\\xe5\\x81\\xbf)N\\xc2\\xb7m";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
armcontrol_msgs__msg__MitCmd__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {armcontrol_msgs__msg__MitCmd__TYPE_NAME, 26, 26},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 423, 423},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
armcontrol_msgs__msg__MitCmd__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *armcontrol_msgs__msg__MitCmd__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
