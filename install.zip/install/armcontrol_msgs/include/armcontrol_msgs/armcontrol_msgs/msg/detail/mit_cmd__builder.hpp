// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_cmd.hpp"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__BUILDER_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "armcontrol_msgs/msg/detail/mit_cmd__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace armcontrol_msgs
{

namespace msg
{

namespace builder
{

class Init_MitCmd_tau_ff
{
public:
  explicit Init_MitCmd_tau_ff(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  ::armcontrol_msgs::msg::MitCmd tau_ff(::armcontrol_msgs::msg::MitCmd::_tau_ff_type arg)
  {
    msg_.tau_ff = std::move(arg);
    return std::move(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_dq_des
{
public:
  explicit Init_MitCmd_dq_des(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  Init_MitCmd_tau_ff dq_des(::armcontrol_msgs::msg::MitCmd::_dq_des_type arg)
  {
    msg_.dq_des = std::move(arg);
    return Init_MitCmd_tau_ff(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_q_des
{
public:
  explicit Init_MitCmd_q_des(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  Init_MitCmd_dq_des q_des(::armcontrol_msgs::msg::MitCmd::_q_des_type arg)
  {
    msg_.q_des = std::move(arg);
    return Init_MitCmd_dq_des(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_kd
{
public:
  explicit Init_MitCmd_kd(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  Init_MitCmd_q_des kd(::armcontrol_msgs::msg::MitCmd::_kd_type arg)
  {
    msg_.kd = std::move(arg);
    return Init_MitCmd_q_des(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_kp
{
public:
  explicit Init_MitCmd_kp(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  Init_MitCmd_kd kp(::armcontrol_msgs::msg::MitCmd::_kp_type arg)
  {
    msg_.kp = std::move(arg);
    return Init_MitCmd_kd(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_name
{
public:
  explicit Init_MitCmd_name(::armcontrol_msgs::msg::MitCmd & msg)
  : msg_(msg)
  {}
  Init_MitCmd_kp name(::armcontrol_msgs::msg::MitCmd::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_MitCmd_kp(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

class Init_MitCmd_header
{
public:
  Init_MitCmd_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MitCmd_name header(::armcontrol_msgs::msg::MitCmd::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_MitCmd_name(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitCmd msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::armcontrol_msgs::msg::MitCmd>()
{
  return armcontrol_msgs::msg::builder::Init_MitCmd_header();
}

}  // namespace armcontrol_msgs

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__BUILDER_HPP_
