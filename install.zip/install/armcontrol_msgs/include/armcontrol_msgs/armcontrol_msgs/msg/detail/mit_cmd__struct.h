﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_cmd.h"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_H_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'kp'
// Member 'kd'
// Member 'q_des'
// Member 'dq_des'
// Member 'tau_ff'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/MitCmd in the package armcontrol_msgs.
/**
  * MitCmd —— 仿真 MIT 力位混合控制指令(每个关节 5 个量)
  * 由 arm_control_node_sim 发到 /sim/<side>/mit_cmd,MuJoCo plant 复现:
  *   tau = kp*(q_des - q) + kd*(dq_des - dq) + tau_ff
  * 各数组长度 = 关节数 N(7),按关节顺序对应 name。
 */
typedef struct armcontrol_msgs__msg__MitCmd
{
  std_msgs__msg__Header header;
  /// 关节名,如 joint1-l .. joint7-l
  rosidl_runtime_c__String__Sequence name;
  /// 比例增益
  rosidl_runtime_c__double__Sequence kp;
  /// 微分增益
  rosidl_runtime_c__double__Sequence kd;
  /// 目标位置 rad
  rosidl_runtime_c__double__Sequence q_des;
  /// 目标速度 rad/s
  rosidl_runtime_c__double__Sequence dq_des;
  /// 前馈力矩(重力/动力学补偿)N·m
  rosidl_runtime_c__double__Sequence tau_ff;
} armcontrol_msgs__msg__MitCmd;

// Struct for a sequence of armcontrol_msgs__msg__MitCmd.
typedef struct armcontrol_msgs__msg__MitCmd__Sequence
{
  armcontrol_msgs__msg__MitCmd * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} armcontrol_msgs__msg__MitCmd__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_CMD__STRUCT_H_
