// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "armcontrol_msgs/msg/mit_state.hpp"


#ifndef ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__BUILDER_HPP_
#define ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "armcontrol_msgs/msg/detail/mit_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace armcontrol_msgs
{

namespace msg
{

namespace builder
{

class Init_MitState_tau
{
public:
  explicit Init_MitState_tau(::armcontrol_msgs::msg::MitState & msg)
  : msg_(msg)
  {}
  ::armcontrol_msgs::msg::MitState tau(::armcontrol_msgs::msg::MitState::_tau_type arg)
  {
    msg_.tau = std::move(arg);
    return std::move(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitState msg_;
};

class Init_MitState_dq
{
public:
  explicit Init_MitState_dq(::armcontrol_msgs::msg::MitState & msg)
  : msg_(msg)
  {}
  Init_MitState_tau dq(::armcontrol_msgs::msg::MitState::_dq_type arg)
  {
    msg_.dq = std::move(arg);
    return Init_MitState_tau(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitState msg_;
};

class Init_MitState_q
{
public:
  explicit Init_MitState_q(::armcontrol_msgs::msg::MitState & msg)
  : msg_(msg)
  {}
  Init_MitState_dq q(::armcontrol_msgs::msg::MitState::_q_type arg)
  {
    msg_.q = std::move(arg);
    return Init_MitState_dq(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitState msg_;
};

class Init_MitState_name
{
public:
  explicit Init_MitState_name(::armcontrol_msgs::msg::MitState & msg)
  : msg_(msg)
  {}
  Init_MitState_q name(::armcontrol_msgs::msg::MitState::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_MitState_q(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitState msg_;
};

class Init_MitState_header
{
public:
  Init_MitState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MitState_name header(::armcontrol_msgs::msg::MitState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_MitState_name(msg_);
  }

private:
  ::armcontrol_msgs::msg::MitState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::armcontrol_msgs::msg::MitState>()
{
  return armcontrol_msgs::msg::builder::Init_MitState_header();
}

}  // namespace armcontrol_msgs

#endif  // ARMCONTROL_MSGS__MSG__DETAIL__MIT_STATE__BUILDER_HPP_
