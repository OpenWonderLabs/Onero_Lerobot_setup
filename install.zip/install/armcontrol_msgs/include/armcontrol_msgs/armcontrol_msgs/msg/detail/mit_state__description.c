// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from armcontrol_msgs:msg/MitState.idl
// generated code does not contain a copyright notice

#include "armcontrol_msgs/msg/detail/mit_state__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_armcontrol_msgs
const rosidl_type_hash_t *
armcontrol_msgs__msg__MitState__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xec, 0x38, 0xca, 0x6e, 0x1e, 0xd1, 0xbe, 0x9a,
      0x6b, 0xf4, 0xf9, 0x21, 0xdf, 0x8f, 0x38, 0x61,
      0x7d, 0xa3, 0x90, 0xd4, 0x14, 0x5b, 0xc0, 0x47,
      0x06, 0xb5, 0x81, 0x23, 0x93, 0xaf, 0xae, 0x4c,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "std_msgs/msg/detail/header__functions.h"
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
static const rosidl_type_hash_t std_msgs__msg__Header__EXPECTED_HASH = {1, {
    0xf4, 0x9f, 0xb3, 0xae, 0x2c, 0xf0, 0x70, 0xf7,
    0x93, 0x64, 0x5f, 0xf7, 0x49, 0x68, 0x3a, 0xc6,
    0xb0, 0x62, 0x03, 0xe4, 0x1c, 0x89, 0x1e, 0x17,
    0x70, 0x1b, 0x1c, 0xb5, 0x97, 0xce, 0x6a, 0x01,
  }};
#endif

static char armcontrol_msgs__msg__MitState__TYPE_NAME[] = "armcontrol_msgs/msg/MitState";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";
static char std_msgs__msg__Header__TYPE_NAME[] = "std_msgs/msg/Header";

// Define type names, field names, and default values
static char armcontrol_msgs__msg__MitState__FIELD_NAME__header[] = "header";
static char armcontrol_msgs__msg__MitState__FIELD_NAME__name[] = "name";
static char armcontrol_msgs__msg__MitState__FIELD_NAME__q[] = "q";
static char armcontrol_msgs__msg__MitState__FIELD_NAME__dq[] = "dq";
static char armcontrol_msgs__msg__MitState__FIELD_NAME__tau[] = "tau";

static rosidl_runtime_c__type_description__Field armcontrol_msgs__msg__MitState__FIELDS[] = {
  {
    {armcontrol_msgs__msg__MitState__FIELD_NAME__header, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitState__FIELD_NAME__name, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitState__FIELD_NAME__q, 1, 1},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitState__FIELD_NAME__dq, 2, 2},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {armcontrol_msgs__msg__MitState__FIELD_NAME__tau, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE_UNBOUNDED_SEQUENCE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription armcontrol_msgs__msg__MitState__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
  {
    {std_msgs__msg__Header__TYPE_NAME, 19, 19},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
armcontrol_msgs__msg__MitState__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {armcontrol_msgs__msg__MitState__TYPE_NAME, 28, 28},
      {armcontrol_msgs__msg__MitState__FIELDS, 5, 5},
    },
    {armcontrol_msgs__msg__MitState__REFERENCED_TYPE_DESCRIPTIONS, 2, 2},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    assert(0 == memcmp(&std_msgs__msg__Header__EXPECTED_HASH, std_msgs__msg__Header__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[1].fields = std_msgs__msg__Header__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# MitState \\xe2\\x80\\x94\\xe2\\x80\\x94 \\xe4\\xbb\\xbf\\xe7\\x9c\\x9f\\xe7\\x8a\\xb6\\xe6\\x80\\x81\\xe5\\x8f\\x8d\\xe9\\xa6\\x88(\\xe4\\xb8\\x8e MitCmd \\xe5\\xad\\x97\\xe6\\xae\\xb5\\xe5\\xaf\\xb9\\xe7\\xa7\\xb0,\\xe4\\xbe\\xbf\\xe4\\xba\\x8e cmd/\\xe5\\xae\\x9e\\xe9\\x99\\x85\\xe5\\xaf\\xb9\\xe6\\xaf\\x94)\n"
  "# \\xe7\\x94\\xb1 MuJoCo plant \\xe5\\x8f\\x91\\xe5\\x88\\xb0 /sim/<side>/state,arm_control_node_sim \\xe8\\xaf\\xbb\\xe5\\x9b\\x9e\\xe5\\xbd\\x93\\xe4\\xbd\\x9c\\xe7\\x94\\xb5\\xe6\\x9c\\xba\\xe8\\xaf\\xbb\\xe6\\x95\\xb0\\xe3\\x80\\x82\n"
  "# \\xe5\\x90\\x84\\xe6\\x95\\xb0\\xe7\\xbb\\x84\\xe9\\x95\\xbf\\xe5\\xba\\xa6 = \\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe6\\x95\\xb0 N(7),\\xe6\\x8c\\x89\\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe9\\xa1\\xba\\xe5\\xba\\x8f\\xe5\\xaf\\xb9\\xe5\\xba\\x94 name[i]\\xe3\\x80\\x82\n"
  "std_msgs/Header header\n"
  "string[]  name      # \\xe5\\x85\\xb3\\xe8\\x8a\\x82\\xe5\\x90\\x8d,\\xe5\\xa6\\x82 joint1-l .. joint7-l\n"
  "float64[] q         # \\xe5\\xae\\x9e\\xe9\\x99\\x85\\xe4\\xbd\\x8d\\xe7\\xbd\\xae rad\n"
  "float64[] dq        # \\xe5\\xae\\x9e\\xe9\\x99\\x85\\xe9\\x80\\x9f\\xe5\\xba\\xa6 rad/s\n"
  "float64[] tau       # \\xe5\\xae\\x9e\\xe9\\x99\\x85\\xe6\\x96\\xbd\\xe5\\x8a\\xa0\\xe5\\x8a\\x9b\\xe7\\x9f\\xa9(qfrc_applied)N\\xc2\\xb7m";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
armcontrol_msgs__msg__MitState__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {armcontrol_msgs__msg__MitState__TYPE_NAME, 28, 28},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 335, 335},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
armcontrol_msgs__msg__MitState__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[3];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 3, 3};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *armcontrol_msgs__msg__MitState__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    sources[2] = *std_msgs__msg__Header__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
