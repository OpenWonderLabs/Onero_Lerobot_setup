// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from armcontrol_msgs:msg/MitCmd.idl
// generated code does not contain a copyright notice
#include "armcontrol_msgs/msg/detail/mit_cmd__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `kp`
// Member `kd`
// Member `q_des`
// Member `dq_des`
// Member `tau_ff`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
armcontrol_msgs__msg__MitCmd__init(armcontrol_msgs__msg__MitCmd * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__init(&msg->name, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__init(&msg->kp, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__init(&msg->kd, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // q_des
  if (!rosidl_runtime_c__double__Sequence__init(&msg->q_des, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // dq_des
  if (!rosidl_runtime_c__double__Sequence__init(&msg->dq_des, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  // tau_ff
  if (!rosidl_runtime_c__double__Sequence__init(&msg->tau_ff, 0)) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
    return false;
  }
  return true;
}

void
armcontrol_msgs__msg__MitCmd__fini(armcontrol_msgs__msg__MitCmd * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // name
  rosidl_runtime_c__String__Sequence__fini(&msg->name);
  // kp
  rosidl_runtime_c__double__Sequence__fini(&msg->kp);
  // kd
  rosidl_runtime_c__double__Sequence__fini(&msg->kd);
  // q_des
  rosidl_runtime_c__double__Sequence__fini(&msg->q_des);
  // dq_des
  rosidl_runtime_c__double__Sequence__fini(&msg->dq_des);
  // tau_ff
  rosidl_runtime_c__double__Sequence__fini(&msg->tau_ff);
}

bool
armcontrol_msgs__msg__MitCmd__are_equal(const armcontrol_msgs__msg__MitCmd * lhs, const armcontrol_msgs__msg__MitCmd * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->kp), &(rhs->kp)))
  {
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->kd), &(rhs->kd)))
  {
    return false;
  }
  // q_des
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->q_des), &(rhs->q_des)))
  {
    return false;
  }
  // dq_des
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->dq_des), &(rhs->dq_des)))
  {
    return false;
  }
  // tau_ff
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->tau_ff), &(rhs->tau_ff)))
  {
    return false;
  }
  return true;
}

bool
armcontrol_msgs__msg__MitCmd__copy(
  const armcontrol_msgs__msg__MitCmd * input,
  armcontrol_msgs__msg__MitCmd * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->kp), &(output->kp)))
  {
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->kd), &(output->kd)))
  {
    return false;
  }
  // q_des
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->q_des), &(output->q_des)))
  {
    return false;
  }
  // dq_des
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->dq_des), &(output->dq_des)))
  {
    return false;
  }
  // tau_ff
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->tau_ff), &(output->tau_ff)))
  {
    return false;
  }
  return true;
}

armcontrol_msgs__msg__MitCmd *
armcontrol_msgs__msg__MitCmd__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitCmd * msg = (armcontrol_msgs__msg__MitCmd *)allocator.allocate(sizeof(armcontrol_msgs__msg__MitCmd), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(armcontrol_msgs__msg__MitCmd));
  bool success = armcontrol_msgs__msg__MitCmd__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
armcontrol_msgs__msg__MitCmd__destroy(armcontrol_msgs__msg__MitCmd * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    armcontrol_msgs__msg__MitCmd__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
armcontrol_msgs__msg__MitCmd__Sequence__init(armcontrol_msgs__msg__MitCmd__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitCmd * data = NULL;

  if (size) {
    data = (armcontrol_msgs__msg__MitCmd *)allocator.zero_allocate(size, sizeof(armcontrol_msgs__msg__MitCmd), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = armcontrol_msgs__msg__MitCmd__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        armcontrol_msgs__msg__MitCmd__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
armcontrol_msgs__msg__MitCmd__Sequence__fini(armcontrol_msgs__msg__MitCmd__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      armcontrol_msgs__msg__MitCmd__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

armcontrol_msgs__msg__MitCmd__Sequence *
armcontrol_msgs__msg__MitCmd__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  armcontrol_msgs__msg__MitCmd__Sequence * array = (armcontrol_msgs__msg__MitCmd__Sequence *)allocator.allocate(sizeof(armcontrol_msgs__msg__MitCmd__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = armcontrol_msgs__msg__MitCmd__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
armcontrol_msgs__msg__MitCmd__Sequence__destroy(armcontrol_msgs__msg__MitCmd__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    armcontrol_msgs__msg__MitCmd__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
armcontrol_msgs__msg__MitCmd__Sequence__are_equal(const armcontrol_msgs__msg__MitCmd__Sequence * lhs, const armcontrol_msgs__msg__MitCmd__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!armcontrol_msgs__msg__MitCmd__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
armcontrol_msgs__msg__MitCmd__Sequence__copy(
  const armcontrol_msgs__msg__MitCmd__Sequence * input,
  armcontrol_msgs__msg__MitCmd__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(armcontrol_msgs__msg__MitCmd);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    armcontrol_msgs__msg__MitCmd * data =
      (armcontrol_msgs__msg__MitCmd *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!armcontrol_msgs__msg__MitCmd__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          armcontrol_msgs__msg__MitCmd__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!armcontrol_msgs__msg__MitCmd__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
