// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARMCONTROL_MSGS__MSG__MIT_STATE_HPP_
#define ARMCONTROL_MSGS__MSG__MIT_STATE_HPP_

#include "armcontrol_msgs/msg/detail/mit_state__struct.hpp"
#include "armcontrol_msgs/msg/detail/mit_state__builder.hpp"
#include "armcontrol_msgs/msg/detail/mit_state__traits.hpp"
#include "armcontrol_msgs/msg/detail/mit_state__type_support.hpp"

#endif  // ARMCONTROL_MSGS__MSG__MIT_STATE_HPP_
