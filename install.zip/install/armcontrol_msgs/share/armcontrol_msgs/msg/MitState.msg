# MitState —— 仿真状态反馈(与 MitCmd 字段对称,便于 cmd/实际对比)
# 由 MuJoCo plant 发到 /sim/<side>/state,arm_control_node_sim 读回当作电机读数。
# 各数组长度 = 关节数 N(7),按关节顺序对应 name[i]。
std_msgs/Header header
string[]  name      # 关节名,如 joint1-l .. joint7-l
float64[] q         # 实际位置 rad
float64[] dq        # 实际速度 rad/s
float64[] tau       # 实际施加力矩(qfrc_applied)N·m
