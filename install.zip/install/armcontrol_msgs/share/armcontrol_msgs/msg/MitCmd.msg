# MitCmd —— 仿真 MIT 力位混合控制指令(每个关节 5 个量)
# 由 arm_control_node_sim 发到 /sim/<side>/mit_cmd,MuJoCo plant 复现:
#   tau = kp*(q_des - q) + kd*(dq_des - dq) + tau_ff
# 各数组长度 = 关节数 N(7),按关节顺序对应 name[i]。
std_msgs/Header header
string[]  name      # 关节名,如 joint1-l .. joint7-l
float64[] kp        # 比例增益
float64[] kd        # 微分增益
float64[] q_des     # 目标位置 rad
float64[] dq_des    # 目标速度 rad/s
float64[] tau_ff    # 前馈力矩(重力/动力学补偿)N·m
