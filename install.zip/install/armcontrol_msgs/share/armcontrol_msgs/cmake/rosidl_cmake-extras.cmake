# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(armcontrol_msgs_IDL_FILES "msg/MitCmd.idl;msg/MitState.idl")
set(armcontrol_msgs_INTERFACE_FILES "msg/MitCmd.msg;msg/MitState.msg")
