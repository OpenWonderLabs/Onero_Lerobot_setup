#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wlabs_logger::wlabs_logger" for configuration ""
set_property(TARGET wlabs_logger::wlabs_logger APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(wlabs_logger::wlabs_logger PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libwlabs_logger.a"
  )

list(APPEND _cmake_import_check_targets wlabs_logger::wlabs_logger )
list(APPEND _cmake_import_check_files_for_wlabs_logger::wlabs_logger "${_IMPORT_PREFIX}/lib/libwlabs_logger.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
