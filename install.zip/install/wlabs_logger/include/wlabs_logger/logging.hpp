//
// wlabs_logger - 独立 spdlog 日志库
//
// 从 wlabs_api (Woan Technology, Author: Albert Lv) 抽取，仅依赖 spdlog，
// 用于替换 ROS 2 的 RCLCPP 日志接口。
//
// 用法：
//   #include "wlabs_logger/logging.hpp"
//   int main(int argc, char* argv[]) {
//     logger_init(argc, argv);                       // 仅需一次
//     auto log = wlabs::get_logger("my_node");       // 带名字的 logger
//     WLABS_INFO(log, "x=%d", x);                     // printf 风格
//   }
//

#pragma once

#include <spdlog/spdlog.h>

#ifdef SPDLOG_FMT_EXTERNAL
#include <fmt/printf.h>
#else
#include <spdlog/fmt/bundled/printf.h>
#endif

#include <atomic>
#include <chrono>
#include <exception>
#include <memory>
#include <string>

// 初始化全局日志：建立控制台彩色 sink + 轮转文件 sink、异步 logger 与统一格式。
// 在每个进程的 main 中调用一次。文件名取 argv[0] 的可执行名，目录取 $LOG_DIR
// 否则系统 temp 目录。argc 暂未使用，保留以贴合 rclcpp::init(argc, argv) 形式。
void logger_init(int argc, char* argv[]);

namespace wlabs {
using Logger = spdlog::logger;

// 返回全局默认 logger（logger_init 建立）。
std::shared_ptr<Logger> default_logger();

// 在全局配置基础上克隆出一个带名字的 logger（线程安全，重复调用返回同一个）。
// 名字会通过 pattern 中的 %n 打印出来，用于区分各节点。
std::shared_ptr<Logger> get_logger(const std::string& name);
}  // namespace wlabs

template <class loggerPtr, class... Args>
void loglineprintf(loggerPtr logger, spdlog::level::level_enum level,
                   spdlog::source_loc loc, const char* fmt,
                   const Args&... args) noexcept {
  if (logger && logger->should_log(level)) {
    // fmt::sprintf 在格式串与参数类型不匹配（如 %d 配字符串）时会抛
    // fmt::format_error。日志绝不能把进程打挂，这里兜底：降级为原样输出
    // 格式串并标注错误，异常一律不外抛（本函数 noexcept）。
    try {
      logger->log(loc, level, "{}", fmt::sprintf(fmt, args...));
    } catch (const std::exception& e) {
      try {
        logger->log(loc, level, "[wlabs_logger 格式化失败: {}] {}", e.what(),
                    fmt);
      } catch (...) {
      }
    } catch (...) {
    }
  }
}

#define SPDLOG_LOGGER_PRINTF(logger, level, ...)                         \
  loglineprintf(logger, level,                                           \
                spdlog::source_loc{__FILE__, __LINE__, SPDLOG_FUNCTION}, \
                __VA_ARGS__)

// printf 风格日志宏。第一个参数为 logger（std::shared_ptr<spdlog::logger>），
// 与 RCLCPP_* 参数个数一致，便于迁移：
//   RCLCPP_INFO(this->get_logger(), "x=%d", x)  ->  WLABS_INFO(log_, "x=%d", x)
#ifdef DEBUG
#define WLABS_DEBUG(logger, ...) \
  SPDLOG_LOGGER_PRINTF(logger, spdlog::level::debug, __VA_ARGS__)
#else
#define WLABS_DEBUG(logger, ...)
#endif

#define WLABS_INFO(logger, ...) \
  SPDLOG_LOGGER_PRINTF(logger, spdlog::level::info, __VA_ARGS__)

#define WLABS_WARN(logger, ...) \
  SPDLOG_LOGGER_PRINTF(logger, spdlog::level::warn, __VA_ARGS__)

#define WLABS_ERROR(logger, ...) \
  SPDLOG_LOGGER_PRINTF(logger, spdlog::level::err, __VA_ARGS__)

#define WLABS_FATAL(logger, ...) \
  SPDLOG_LOGGER_PRINTF(logger, spdlog::level::critical, __VA_ARGS__)

// ---- 节流日志（对应 RCLCPP_*_THROTTLE）---------------------------------
//
// 与 RCLCPP_*_THROTTLE 的区别：本库不依赖 rclcpp，故 *不* 接收 clock 参数，
// 内部使用 std::chrono::steady_clock（单调时钟，不受系统时间调整影响）。
// period_ms 为节流周期（毫秒），与 RCLCPP_*_THROTTLE 第三个参数单位一致。
//   RCLCPP_WARN_THROTTLE(log, *get_clock(), 1000, "x=%d", x)
//     ->  WLABS_WARN_THROTTLE(log_, 1000, "x=%d", x)
//
// 每个调用点有独立的静态计时状态；首次命中立即输出，之后每 period_ms 最多一条。
// 计时状态用 relaxed atomic，多线程命中同一调用点时可能多放行一两条（良性竞争）。

namespace wlabs {
namespace detail {
// 节流计时判定：距上次放行超过 period_ms（或首次，last==0）则更新时间戳并放行。
// 计时局部变量放在函数里而非宏体内，避免与用户的格式参数同名时被静默捕获。
inline bool throttle_ready(std::atomic<long long>& last_ms,
                           long long period_ms) noexcept {
  const long long now_ms =
      std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::steady_clock::now().time_since_epoch())
          .count();
  const long long last = last_ms.load(std::memory_order_relaxed);
  if (last == 0 || now_ms - last >= period_ms) {
    last_ms.store(now_ms, std::memory_order_relaxed);
    return true;
  }
  return false;
}
}  // namespace detail
}  // namespace wlabs

#define WLABS_LOG_THROTTLE(logger, level, period_ms, ...)                    \
  do {                                                                       \
    static std::atomic<long long> _wlabs_throttle_last_ms{0};                \
    if (wlabs::detail::throttle_ready(_wlabs_throttle_last_ms,               \
                                      static_cast<long long>(period_ms))) {  \
      SPDLOG_LOGGER_PRINTF(logger, level, __VA_ARGS__);                      \
    }                                                                        \
  } while (0)

#define WLABS_INFO_THROTTLE(logger, period_ms, ...) \
  WLABS_LOG_THROTTLE(logger, spdlog::level::info, period_ms, __VA_ARGS__)

#define WLABS_WARN_THROTTLE(logger, period_ms, ...) \
  WLABS_LOG_THROTTLE(logger, spdlog::level::warn, period_ms, __VA_ARGS__)

#define WLABS_ERROR_THROTTLE(logger, period_ms, ...) \
  WLABS_LOG_THROTTLE(logger, spdlog::level::err, period_ms, __VA_ARGS__)

#ifdef DEBUG
#define WLABS_DEBUG_THROTTLE(logger, period_ms, ...) \
  WLABS_LOG_THROTTLE(logger, spdlog::level::debug, period_ms, __VA_ARGS__)
#else
#define WLABS_DEBUG_THROTTLE(logger, period_ms, ...)
#endif
